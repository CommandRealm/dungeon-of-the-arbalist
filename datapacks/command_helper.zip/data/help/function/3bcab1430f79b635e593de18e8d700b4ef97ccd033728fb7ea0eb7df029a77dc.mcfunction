data modify storage help:data safe_nbt_interpret set value {}

data modify storage help:data safe_nbt_interpret.v0 set value "null"
data modify storage help:data safe_nbt_interpret.v0 set from entity @e[type=minecraft:area_effect_cloud,tag=mapping_marker,scores={grid_x=-2,grid_z=0},limit=1] CustomName
execute if data storage help:data {safe_nbt_interpret:{v0:"null"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:[]}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:"[]"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'

data modify storage help:data safe_nbt_interpret.v1 set value "null"
data modify storage help:data safe_nbt_interpret.v1 set from entity @e[type=minecraft:area_effect_cloud,tag=mapping_marker,scores={grid_x=-1,grid_z=0},limit=1] CustomName
execute if data storage help:data {safe_nbt_interpret:{v1:"null"}} run data modify storage help:data safe_nbt_interpret.v1 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v1:[]}} run data modify storage help:data safe_nbt_interpret.v1 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v1:"[]"}} run data modify storage help:data safe_nbt_interpret.v1 set value '{"type":"text","text":""}'

data modify storage help:data safe_nbt_interpret.v2 set value "null"
data modify storage help:data safe_nbt_interpret.v2 set from entity @e[type=minecraft:area_effect_cloud,tag=mapping_marker,scores={grid_x=1,grid_z=0},limit=1] CustomName
execute if data storage help:data {safe_nbt_interpret:{v2:"null"}} run data modify storage help:data safe_nbt_interpret.v2 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v2:[]}} run data modify storage help:data safe_nbt_interpret.v2 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v2:"[]"}} run data modify storage help:data safe_nbt_interpret.v2 set value '{"type":"text","text":""}'

data modify storage help:data safe_nbt_interpret.v3 set value "null"
data modify storage help:data safe_nbt_interpret.v3 set from entity @e[type=minecraft:area_effect_cloud,tag=mapping_marker,scores={grid_x=2,grid_z=0},limit=1] CustomName
execute if data storage help:data {safe_nbt_interpret:{v3:"null"}} run data modify storage help:data safe_nbt_interpret.v3 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v3:[]}} run data modify storage help:data safe_nbt_interpret.v3 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v3:"[]"}} run data modify storage help:data safe_nbt_interpret.v3 set value '{"type":"text","text":""}'

return run tellraw @s [{"text":"                                ","type":"text"},{"interpret":true,"nbt":"safe_nbt_interpret.v0","source":"storage","storage":"help:data","type":"nbt"},{"interpret":true,"nbt":"safe_nbt_interpret.v1","source":"storage","storage":"help:data","type":"nbt"},{"text":"█","obfuscated":true,"color":"#ab0909","strikethrough":true,"type":"text"},{"interpret":true,"nbt":"safe_nbt_interpret.v2","source":"storage","storage":"help:data","type":"nbt"},{"interpret":true,"nbt":"safe_nbt_interpret.v3","source":"storage","storage":"help:data","type":"nbt"}]