data modify storage help:data safe_nbt_interpret set value {}

data modify storage help:data safe_nbt_interpret.v0 set value "null"
data modify storage help:data safe_nbt_interpret.v0 set from entity @s Inventory[{Slot:8b}].components."minecraft:custom_name"
execute if data storage help:data {safe_nbt_interpret:{v0:"null"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:[]}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:"[]"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'

return run tellraw @s [{"text":"- ","color":"gray","type":"text"},{"text":"Objective completed!\n","color":"gold","type":"text"},{"text":"Current ","color":"dark_purple","bold":true,"type":"text"},{"nbt":"safe_nbt_interpret.v0","interpret":true,"source":"storage","storage":"help:data","type":"nbt"}]