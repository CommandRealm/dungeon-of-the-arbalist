effect give @a[tag=playing] minecraft:jump_boost 100000 200 true
execute as @a[tag=playing] if entity @s[type=minecraft:player,predicate=effect:jump_boost] run function effect:jump_boost/check
return 1