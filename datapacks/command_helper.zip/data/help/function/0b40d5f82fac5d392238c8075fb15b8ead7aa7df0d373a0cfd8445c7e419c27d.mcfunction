effect give @e[distance=..2,tag=enemy,tag=!boss] minecraft:levitation 1 7 false
execute as @e[distance=..2,tag=enemy,tag=!boss] if entity @s[type=minecraft:player,predicate=effect:levitation] run function effect:levitation/check
return 1