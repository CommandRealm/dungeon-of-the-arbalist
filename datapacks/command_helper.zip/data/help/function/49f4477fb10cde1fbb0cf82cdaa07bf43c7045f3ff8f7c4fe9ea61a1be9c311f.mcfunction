data modify storage help:data safe_nbt_interpret set value {}

data modify storage help:data safe_nbt_interpret.v0 set value "null"
data modify storage help:data safe_nbt_interpret.v0 set from entity @s Inventory[0].components."minecraft:lore"[0]
execute if data storage help:data {safe_nbt_interpret:{v0:"null"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:[]}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:"[]"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'

return run tellraw @s [{"text":"=- ","color":"green","type":"text"},{"text":"Effects","color":"gold","bold":true,"type":"text"},{"text":" -=","color":"green","type":"text"},{"text":"\n","type":"text"},{"nbt":"safe_nbt_interpret.v0","interpret":true,"source":"storage","storage":"help:data","type":"nbt"}]