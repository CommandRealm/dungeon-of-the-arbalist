effect give @s[tag=!boss] minecraft:levitation 1 7 true
execute as @s[tag=!boss] if entity @s[type=minecraft:player,predicate=effect:levitation] run function effect:levitation/check
return 1