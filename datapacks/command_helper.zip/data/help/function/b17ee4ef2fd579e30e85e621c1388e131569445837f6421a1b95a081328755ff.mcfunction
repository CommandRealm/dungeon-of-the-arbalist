effect clear @a[tag=playing]
execute as @a[tag=playing] if entity @s[type=minecraft:player] run function effect:remove_all
return 1