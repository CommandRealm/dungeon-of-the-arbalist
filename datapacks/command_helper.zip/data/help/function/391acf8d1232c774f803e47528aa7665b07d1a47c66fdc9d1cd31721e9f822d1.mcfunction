data modify storage help:data safe_nbt_interpret set value {}

data modify storage help:data safe_nbt_interpret.v0 set value "null"
data modify storage help:data safe_nbt_interpret.v0 set from block 0 10 0 front_text.messages[0]
execute if data storage help:data {safe_nbt_interpret:{v0:"null"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:[]}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:"[]"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'

return run data modify block 0 10 0 front_text.messages[1] set value '[{"text":"","italic":false,"type":"text"},{"selector":"@p[tag=temporary_tag]","type":"selector"},{"text":"\'s ","color":"yellow","type":"text"},{"text":"time: ","color":"gray","type":"text"},{"nbt":"safe_nbt_interpret.v0","interpret":true,"source":"storage","storage":"help:data","type":"nbt"}]'