data modify storage help:data safe_nbt_interpret set value {}

data modify storage help:data safe_nbt_interpret.v0 set value "null"
data modify storage help:data safe_nbt_interpret.v0 set from entity @e[type=minecraft:armor_stand,tag=temporary_tag,sort=nearest,limit=1] ArmorItems[3].components."minecraft:custom_data".current_colored
execute if data storage help:data {safe_nbt_interpret:{v0:"null"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:[]}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:"[]"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'

data modify storage help:data safe_nbt_interpret.v1 set value "null"
data modify storage help:data safe_nbt_interpret.v1 set from entity @e[type=minecraft:armor_stand,tag=temporary_tag,sort=nearest,limit=1] ArmorItems[3].components."minecraft:custom_data".current
execute if data storage help:data {safe_nbt_interpret:{v1:"null"}} run data modify storage help:data safe_nbt_interpret.v1 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v1:[]}} run data modify storage help:data safe_nbt_interpret.v1 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v1:"[]"}} run data modify storage help:data safe_nbt_interpret.v1 set value '{"type":"text","text":""}'

return run setblock 0 10 0 minecraft:oak_sign{front_text:{messages:['[{"text":"","bold":true,"type":"text"},{"text":"☣","color":"dark_green","bold":false,"type":"text"},{"text":" - ","color":"gray","bold":true,"type":"text"},{"nbt":"safe_nbt_interpret.v0","interpret":true,"color":"green","underlined":true,"source":"storage","storage":"help:data","type":"nbt"},{"nbt":"safe_nbt_interpret.v1","interpret":true,"color":"white","source":"storage","storage":"help:data","type":"nbt"},{"text":" - ","color":"gray","bold":true,"type":"text"},{"text":"☣","color":"dark_green","bold":false,"type":"text"}]','""','""','""']}} destroy