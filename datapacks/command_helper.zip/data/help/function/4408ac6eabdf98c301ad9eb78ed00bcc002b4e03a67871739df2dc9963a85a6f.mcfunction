effect give @a[tag=playing] minecraft:levitation 100000 255 true
execute as @a[tag=playing] if entity @s[type=minecraft:player,predicate=effect:levitation] run function effect:levitation/check
return 1