data modify storage help:data safe_nbt_interpret set value {}

data modify storage help:data safe_nbt_interpret.v0 set value "null"
data modify storage help:data safe_nbt_interpret.v0 set from block 0 10 0 front_text.messages[0]
execute if data storage help:data {safe_nbt_interpret:{v0:"null"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:[]}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'
execute if data storage help:data {safe_nbt_interpret:{v0:"[]"}} run data modify storage help:data safe_nbt_interpret.v0 set value '{"type":"text","text":""}'

return run tellraw @a ["",{"text":"| ","color":"gray","bold":true,"type":"text"},{"selector":"@s","type":"selector"},{"text":" has finished the ","color":"gold","type":"text"},{"text":"Invaded Castle","color":"dark_green","bold":true,"type":"text"},{"text":" in ","color":"gold","type":"text"},{"nbt":"safe_nbt_interpret.v0","interpret":true,"source":"storage","storage":"help:data","type":"nbt"}]